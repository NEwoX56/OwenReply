import React from 'react';
import { SenderInput } from './SenderInput';

export function TwitterFeatures() {
  return (
    <div className="space-y-4">
      <SenderInput />
    </div>
  );
}