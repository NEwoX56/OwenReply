import { useState } from 'react';
import { useStore } from '../store/useStore';
import { useGeneration } from './useGeneration';
import toast from 'react-hot-toast';

export function useRegenerateResponse() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modificationNote, setModificationNote] = useState('');
  const { generate } = useGeneration();

  const handleRegenerateClick = () => {
    setIsModalOpen(true);
  };

  const handleRegenerateSubmit = async () => {
    if (!modificationNote.trim()) {
      toast.error('Veuillez entrer une note de modification');
      return;
    }

    try {
      await generate(modificationNote);
      setIsModalOpen(false);
      setModificationNote('');
    } catch (error) {
      toast.error('Erreur lors de la régénération de la réponse');
    }
  };

  return {
    isModalOpen,
    setIsModalOpen,
    modificationNote,
    setModificationNote,
    handleRegenerateClick,
    handleRegenerateSubmit
  };
}