import { Platform } from '../../types';
import { LearningFile } from '../../types/files';
import { useStore } from '../../store/useStore';

export abstract class AIService {
  protected apiKey: string;

  constructor(apiKey: string) {
    if (!apiKey) {
      throw new Error('API key is required');
    }
    this.apiKey = apiKey;
  }

  abstract generateResponse(
    platform: Platform,
    message: string,
    tone: string,
    length: string,
    intention: string,
    emailSender: string,
    learningFiles?: LearningFile[],
    previousResponse?: string,
    modificationNote?: string
  ): Promise<string>;

  protected getMaxTokens(length: string): number {
    const tokens = {
      short: 150,
      medium: 300,
      long: 600,
    };
    return tokens[length as keyof typeof tokens] || 300;
  }

  protected getSystemPrompt(
    platform: Platform, 
    tone: string, 
    length: string,
    intention: string,
    emailSender: string,
    learningFiles?: LearningFile[],
    previousResponse?: string,
    modificationNote?: string
  ): string {
    const { settings, preferences } = useStore.getState();
    const { firstName, lastName, email, title, company, phone } = settings.personal;

    let basePrompt = `Tu es un assistant spécialisé dans la génération de réponses ${platform}.`;

    // Si on a une réponse précédente et une note de modification
    if (previousResponse && modificationNote) {
      basePrompt += `\n\nVoici la réponse précédente que tu as générée :
      
"${previousResponse}"

Note de modification demandée : "${modificationNote}"

Ta tâche est de modifier cette réponse en tenant compte de la note de modification tout en conservant le contexte et le ton initial.`;
    } else {
      basePrompt += `\nTa tâche est de créer une réponse ${tone} qui est ${length} en longueur.`;
    }

    basePrompt += `\nLe message provient de : ${emailSender}
Intention de la réponse : ${intention}
IMPORTANT: Utilise exactement le nom "${emailSender}" dans la réponse, ne le remplace pas par un placeholder.`;

    if (preferences.includeSignature) {
      basePrompt += `\n\nUtilise cette signature exacte à la fin du message :

Cordialement,
${firstName} ${lastName}
${title || ''}
${company || ''}
${email || ''}
${phone || ''}`;
    }

    // Ajouter les exemples d'apprentissage si disponibles
    const relevantFiles = learningFiles?.filter(file => file.tone === tone);
    if (relevantFiles?.length) {
      basePrompt += `\n\nVoici des exemples de mon style d'écriture ${tone} :\n\n`;
      relevantFiles.forEach(file => {
        basePrompt += `Exemple de mon style ${tone} :\n${file.content}\n---\n`;
      });
      basePrompt += `\nGénère une réponse qui imite mon style d'écriture ${tone} tout en restant appropriée pour la situation actuelle.`;
    }

    return basePrompt;
  }
}