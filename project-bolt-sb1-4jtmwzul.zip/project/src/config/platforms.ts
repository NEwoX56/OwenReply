import { PlatformConfig } from '../types';
import {
  Mail,
  Linkedin,
  Twitter,
  Instagram,
  Youtube,
  Hash,
  AtSign,
  Paperclip,
  Clock,
  MessageSquare,
  Video,
} from 'lucide-react';

export const platforms: PlatformConfig[] = [
  {
    id: 'gmail',
    label: 'Gmail',
    icon: Mail,
    features: ['Détection du sujet', 'Réponse formelle', 'Pièces jointes', 'Signatures'],
  },
  {
    id: 'linkedin',
    label: 'LinkedIn',
    icon: Linkedin,
    features: ['Réseautage professionnel', 'Expériences communes', 'Demande de connexion'],
  },
  {
    id: 'twitter',
    label: 'Twitter',
    icon: Twitter,
    maxLength: 280,
    features: ['Limite de caractères', 'Hashtags', 'Support de fil', 'Mentions'],
  },
  {
    id: 'instagram',
    label: 'Instagram',
    icon: Instagram,
    features: ['Suggestions d\'émojis', 'Story/Post/DM', 'Mentions', 'Hashtags'],
  },
  {
    id: 'youtube',
    label: 'YouTube',
    icon: Youtube,
    features: ['Commentaire/Réponse', 'Horodatages', 'Références vidéo', 'Filtre spam'],
  },
];